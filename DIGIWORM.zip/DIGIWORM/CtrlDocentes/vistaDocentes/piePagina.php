<table width="70%" border="0" align="center">
  <tr>
    <td><strong></strong>-- “La vida es como el jazz… es mucho mejor si es improvisada.” George Gershwin --<strong></strong>“La vida es como el jazz… es mucho mejor si es improvisada.” George Gershwin </td>
  </tr>
</table>